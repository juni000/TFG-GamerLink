package com.app.web.entidad;

public enum Roles {
	ADMIN,
	USER

	
}
